STATUS_CHOICES = (
    ('#0','rented'),
    ('#1','rerutned'),
    ('#2','lost'),
    ('#3','delayed'),
)