from django.contrib import admin
from .models import Rental
# Register your models here.

admin.site.register(Rental)