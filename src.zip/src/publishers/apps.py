from django.apps import AppConfig


class PublishersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'publishers'
